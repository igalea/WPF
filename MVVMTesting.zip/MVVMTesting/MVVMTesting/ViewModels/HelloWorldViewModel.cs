﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
//using Commander;

namespace MVVMTesting.ViewModels
{
    public class ArrayItem:ViewModelBase
    {
        //Note no raising properties
        public int Col1 { get; set; }
        public string Col2 { get; set; }
        public string Col3 { get; set; }

    }

    public class HelloWorldViewModel : ViewModelBase
    {
        //Note no raising properties
        public ObservableCollection<ArrayItem> TheArray
        {
            get; set;
        }

        public HelloWorldViewModel()
        {
            TheArray = new ObservableCollection<ArrayItem>();
            TheArray.Add(new ArrayItem() { Col1 = 1, Col2 = "hjeelo2", Col3 = "hello3" });
            TheArray.Add(new ArrayItem() { Col1 = 2, Col2 = "hjeelo2", Col3 = "hello3" });
            TheArray.Add(new ArrayItem() { Col1 = 3, Col2 = "hjeelo2", Col3 = "hello3" });
        }

        //Observable collection correctly updates
        public ICommand IncrementCommand
        {
            get  => new RelayCommand(() => TheArray[0].Col1++);
        }

        //ICommand no parameter
        public ICommand AddNewItem
        {
            get  => new RelayCommand(
                ()=>TheArray.Add(new ArrayItem() { Col1 = TheArray.Count + 1, Col2 = "afdasf", Col3 = "adf" }));
        }

        //ICommand using parameter - see how item is retrieved just using "Binding"
        public ICommand RemoveItem
        {
            get => new RelayCommand<object>
                   (x =>TheArray.Remove((ArrayItem)x));
            
        }
    }
}
