﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;

namespace DesignTimeDataTest.ViewModels
{
       
        public class SalesModelViewModel:ViewModelBase
        {
            public List<SaleItem> Items { get; set; }
            public SalesModelViewModel()
            {
                Items = new List<SaleItem>();
            }
        }

        public class SaleItem
        {
            public string Sku { get; set; }
            public string Title { get; set; }
            public double CostPrice { get; set; }
            public int Quantity { get; set; }
        }
    
}
