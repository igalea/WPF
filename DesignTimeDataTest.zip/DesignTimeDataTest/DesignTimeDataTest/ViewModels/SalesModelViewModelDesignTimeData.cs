﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignTimeDataTest.ViewModels
{
    public class SalesModelViewModelDesignTimeData : SalesModelViewModel
    {
        public SalesModelViewModelDesignTimeData()
        {
          
                Items.Add(new SaleItem { Sku = "001", Title = "Pepsi", CostPrice = 10.0, Quantity = 1 });
                Items.Add(new SaleItem { Sku = "002", Title = "Coca Cola", CostPrice = 10.0, Quantity = 1 });
                Items.Add(new SaleItem { Sku = "003", Title = "Colgate Tooth Paste", CostPrice = 8.0, Quantity = 1 });
                Items.Add(new SaleItem { Sku = "004", Title = "Lipton Yello Label", CostPrice = 12.5, Quantity = 1 });
                Items.Add(new SaleItem { Sku = "005", Title = "Sugar", CostPrice = 5.0, Quantity = 1 });
        }
    }
}
